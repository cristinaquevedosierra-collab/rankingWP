# Discovery / Anomalías

## Posibles typos ('Amater' → 'Amateur')
- {"tipoCompeticionId":2,"preferredName":"Amater Dobles","allNames":"Amater Dobles","sources":"Torneo/GetTorneoConPosiciones","samples":346}
- {"tipoCompeticionId":14,"preferredName":"Amater Individual","allNames":"Amater Individual","sources":"Torneo/GetTorneoConPosiciones","samples":21}
- {"categoriaId":2,"preferredName":"Amater","allNames":"Amater"}

