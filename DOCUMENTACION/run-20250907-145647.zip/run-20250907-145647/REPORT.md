# Ranking API Validation

*Base:* https://illozapatillo.zapto.org
*Fecha:* 2025-09-07T14:56:47

## Resultado: **PASS**

## Checks
- ✅ **Modalidades shape** — root=array
- ✅ **Torneos shape (all)** — root=array
- ✅ **Torneos paginados >0** — count=66
- ✅ **UltimoTorneoCalcularGlicko2 tiene torneoId** — keys=
- ✅ **J4 GetDatosJugador ok** — jugadorId=4
- ✅ **J4 PosicionPorTorneos es array** — root=array
- ✅ **J4 PuntuacionCategoria es array** — root=array
- ✅ **J4 Partidos ALL es array** — root=array
- ✅ **J4 Partidos ALL vs PAG coinciden** — OnlyInAll=0; OnlyInPag=0
- ✅ **Ranking ESP m1 array** — root=array
- ✅ **Ranking ESP m1 ALL vs PAG** — OnlyInAll=0; OnlyInPag=0
- ✅ **Ranking EXT m1 array** — root=array
- ✅ **Ranking ESP m2 array** — root=array
- ✅ **Ranking ESP m2 ALL vs PAG** — OnlyInAll=0; OnlyInPag=0
- ✅ **Ranking EXT m2 array** — root=array
- ✅ **Ranking ESP m3 array** — root=array
- ✅ **Ranking ESP m3 ALL vs PAG** — OnlyInAll=0; OnlyInPag=0
- ✅ **Ranking EXT m3 array** — root=array
- ✅ **Ranking ESP m4 array** — root=array
- ✅ **Ranking ESP m4 ALL vs PAG** — OnlyInAll=0; OnlyInPag=0
- ✅ **Ranking EXT m4 array** — root=array
- ✅ **Ranking ESP m5 array** — root=array
- ✅ **Ranking ESP m5 ALL vs PAG** — OnlyInAll=0; OnlyInPag=0
- ✅ **Ranking EXT m5 array** — root=array
- ✅ **Ranking ESP m6 array** — root=array
- ✅ **Ranking ESP m6 ALL vs PAG** — OnlyInAll=0; OnlyInPag=0
- ✅ **Ranking EXT m6 array** — root=array
- ✅ **Ranking ESP m7 array** — root=array
- ✅ **Ranking ESP m7 ALL vs PAG** — OnlyInAll=0; OnlyInPag=0
- ✅ **Ranking EXT m7 array** — root=array
- ✅ **Ranking ESP m8 array** — root=array
- ✅ **Ranking ESP m8 ALL vs PAG** — OnlyInAll=0; OnlyInPag=0
- ✅ **Ranking EXT m8 array** — root=array
- ✅ **Ranking ESP m9 array** — root=array
- ✅ **Ranking ESP m9 ALL vs PAG** — OnlyInAll=0; OnlyInPag=0
- ✅ **Ranking EXT m9 array** — root=array
- ✅ **Ranking ESP m10 array** — root=array
- ✅ **Ranking ESP m10 ALL vs PAG** — OnlyInAll=0; OnlyInPag=0
- ✅ **Ranking EXT m10 array** — root=array
- ✅ **Torneo 135 posiciones ALL vs PAG** — OnlyInAll=0; OnlyInPag=0
- ✅ **Torneo 134 posiciones ALL vs PAG** — OnlyInAll=0; OnlyInPag=0
- ✅ **Torneo 133 posiciones ALL vs PAG** — OnlyInAll=0; OnlyInPag=0
- ✅ **Torneo 130 posiciones ALL vs PAG** — OnlyInAll=0; OnlyInPag=0
- ✅ **Torneo 129 posiciones ALL vs PAG** — OnlyInAll=0; OnlyInPag=0
- ✅ **Torneo 128 posiciones ALL vs PAG** — OnlyInAll=0; OnlyInPag=0
- ✅ **Torneo 126 posiciones ALL vs PAG** — OnlyInAll=0; OnlyInPag=0
- ✅ **Torneo 125 posiciones ALL vs PAG** — OnlyInAll=0; OnlyInPag=0
- ✅ **Torneo 124 posiciones ALL vs PAG** — OnlyInAll=0; OnlyInPag=0
- ✅ **Torneo 123 posiciones ALL vs PAG** — OnlyInAll=0; OnlyInPag=0
- ✅ **Torneo 122 posiciones ALL vs PAG** — OnlyInAll=0; OnlyInPag=0
- ✅ **Torneo 121 posiciones ALL vs PAG** — OnlyInAll=0; OnlyInPag=0
- ✅ **Torneo 120 posiciones ALL vs PAG** — OnlyInAll=0; OnlyInPag=0
- ✅ **Torneo 119 posiciones ALL vs PAG** — OnlyInAll=0; OnlyInPag=0
- ✅ **Torneo 118 posiciones ALL vs PAG** — OnlyInAll=0; OnlyInPag=0
- ✅ **TemporadaId->texto consistente** — ok
