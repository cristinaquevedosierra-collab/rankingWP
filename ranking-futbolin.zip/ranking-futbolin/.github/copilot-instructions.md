# Instrucciones para agentes de IA en este plugin (Ranking Futbolín API)

Contexto: plugin de WordPress para mostrar ranking ELO, perfiles de jugador, Hall of Fame, torneos y vistas relacionadas; consume una API externa con autenticación Bearer y cachea resultados. Código principal en `ranking-futbolin.php` con autoloader y wiring defensivo.

## Arquitectura y puntos de entrada
- Archivo principal: `ranking-futbolin.php`.
  - Define constantes `FUTBOLIN_API_*`, registra autoloader (clases `Futbolin_*` -> `includes/**/class-futbolin-*.php`), y encola assets.
  - Inicializa: shortcodes, AJAX, admin, rutas públicas, HTTP tuning y opciones como “shadow mode”.
- Shortcodes y router:
  - Router: `includes/shortcodes/class-futbolin-shortcode-router.php` expone `[futbolin_ranking]` y deriva por `?view=` a handlers: ranking, global-stats, champions, tournaments, hall-of-fame, finals_reports, info, player.
  - Plantilla envolvente: `includes/template-parts/ranking-wrapper.php` con sidebar y carga de parciales (p. ej. `ranking-display.php`, `hall-of-fame-display.php`). Usa variables `$template_to_load`, `$current_view`, `$hide_sidebar`.
- AJAX público: `includes/ajax/class-futbolin-ajax.php` (búsqueda de jugadores y filtro Hall of Fame). Verifica nonce `futbolin_nonce` y respeta modo mantenimiento público.
- Rutas públicas: `includes/public/class-futbolin-rankgen-route.php` filtra `the_content` cuando `?view=rankgen` y delega a `Futbolin_Rankgen_Shortcode`.
- Servicios y procesadores: `includes/services/**`, `includes/processors/**` realizan cálculo/normalización y compilación de informes.
- Cliente API central: `includes/core/class-futbolin-api-client.php` (login, token en transient, cache negativa por URL, normalización de respuestas, helpers de cache por shards).
- HTTP tuning: `includes/core/class-futbolin-http.php` ajusta timeouts/reintentos solo para URLs de la API; evita recursión con guard interna.

## Datos y configuración
- Resolución de configuración API: `includes/core/futbolin-config.php` resuelve en orden: option `ranking_api_config` → legacy `mi_plugin_futbolin_options` → filtro `futbolin_api_config` → constantes (`FUTBOLIN_API_*`) → fallback `BUENO_master.json` (`meta.baseUrl`).
- Modo mantenimiento: global por shortcode (filtra `do_shortcode_tag`) y específico para AJAX público (`futbolin_public_maintenance`). Devuelve HTML placeholder o error JSON.
- Cache dataset: opción `rf_dataset_ver` con helper `rf_dataset_bump_cache_version()` y comando WP‑CLI `wp rf cache-bust`.

## Assets y estilos
- Encolado front: `Futbolin_Assets` y funciones en `ranking-futbolin.php` cargan `assets/css/*.css` y `assets/js/*.js` (incluye `rf-live-wiring.js` y Lottie).
- Loader CSS “soft” purged: `includes/core/class-futbolin-css-loader.php` detecta `dist/assets/css-purged/` y hace override fuerte del CSS legacy (define `RF_CSS_OVERRIDE_STRONG`). Ver README `README-RF-CSS-OVERRIDE.txt`.
- Modo Shadow DOM opcional: encola `assets/js/rf-shadow.js` y pasa `cssUrls` de estilos a aislar.

## Convenciones de código
- Prefijo de clases: `Futbolin_` con archivo `class-futbolin-<kebab>.php` en `includes/**/` (autoloader recursivo).
- Handlers y plantillas: cada vista selecciona `$template_to_load` y pasa datos mínimos; el wrapper decide sidebar y rutas de retorno.
- API Client: para endpoints agrega métodos en `Futbolin_API_Client` y reutiliza `do_request($url, $auth=true)`; usa `rawurlencode` en segmentos y respeta contrato: `null` para 204, `WP_Error` para fallos.
- AJAX: siempre `check_ajax_referer('futbolin_nonce','security')`, sanitiza entradas (`sanitize_text_field`, `sanitize_key`) y responde con `wp_send_json_success/error`.

## Flujos de trabajo de desarrollo
- Entorno WP: este es un plugin; no hay build de PHP. Asegura WordPress cargado y activa el plugin.
- CSS purged opcional: coloca bundles en `dist/assets/css-purged/` (mínimo `core.css` y `components.css`) para activar override. Limpia cachés tras subir.
- Debug API: ajusta opciones `http_timeout` y `http_retries` en `mi_plugin_futbolin_options`. Para desactivar verificación SSL en llamadas a tu host, el filtro en `ranking-futbolin.php` detecta host base y pone `sslverify=false`.
- Cache bust datasets: ejecuta WP‑CLI `wp rf cache-bust` tras importaciones para invalidar caches largas en `Futbolin_API_Client`.

## Ejemplos prácticos
- Añadir endpoint: crea método en `Futbolin_API_Client` (p. ej. `get_torneos_pag(page,size)`) y consúmelo desde un shortcode o AJAX. Usa `do_request($url,true)` si requiere token.
- Nueva vista `?view=h2h`: añade handler/shortcode en `includes/shortcodes/`, decide `$template_to_load` y deja que el wrapper renderice. Encola JS/CSS mediante `Futbolin_Assets` o localiza a `rf-shadow` si procede.
- AJAX de búsqueda: sigue el patrón de `search_players_callback()` con nonce `futbolin_nonce` y respuesta paginada/ordenada cuando aplique.

## Pitfalls y decisiones
- No hardcodees base_url ni credenciales: usa `futbolin_get_api_config()` o el cliente API.
- Evita colisiones de estilos: respeta el loader purged y el modo Shadow DOM. No incluyas CSS legacy directo en plantillas si `RF_CSS_OVERRIDE_STRONG` está definido.
- Manejo de 204/errores: en cliente API, 204 → `null`; log con `log_once` y cache negativa para evitar martilleo.

Si algo no queda claro (p. ej. ubicaciones exactas de ciertos parciales o servicios específicos), dime qué sección extender o qué flujos documentar mejor y lo actualizo.
