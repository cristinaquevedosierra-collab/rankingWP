/* FUT PATCH24: Historial avanzado (dropdown desde 1ª tecla, etiqueta fija arriba, bloque "Como compañero" condicional) */
(function(){
  if (window.__futPatch24Loaded) return; window.__futPatch24Loaded = true;

  var D = document;
  function $one(sel, ctx){ return (ctx||D).querySelector(sel); }
  function $all(sel, ctx){ return Array.prototype.slice.call((ctx||D).querySelectorAll(sel)); }
  function normEs(s){
    s = String(s||'').toLowerCase();
    try {
      s = s.replace(/ñ/g,'__enye__').replace(/Ñ/g,'__ENYE__');
      s = s.normalize('NFD').replace(/[ -\u001f]/g,' ').replace(/[\u0300-\u036f]/g,'');
      s = s.replace(/__enye__/g,'ñ').replace(/__ENYE__/g,'ñ');
    } catch(e) {
      s = s.replace(/[áàäâ]/g,'a').replace(/[éèëê]/g,'e').replace(/[íìïî]/g,'i').replace(/[óòöô]/g,'o').replace(/[úùüû]/g,'u');
    }
    return s.replace(/\s+/g,' ').trim();
  }

  function setup(){
    // Inicializar por cada bloque de historial presente, sin depender de #tab-historial
    var boxes = $all('.history-summary-search');
    if (!boxes.length) return;

    boxes.forEach(function(box){
      var input = $one('#history-search', box) || $one('input[type="search"]', box) || $one('input[type="text"]', box); if (!input) return;
      if (input.__rfWired) return; input.__rfWired = true;

      // Contenedor lógico: el .futbolin-card más cercano o, en su defecto, el ancestro con id tab-historial; si no, document
      var wrap = box.closest('.futbolin-card') || box.closest('#tab-historial') || D;

  function getRows(){ return $all('.ranking-row.history-match-row', wrap); }
      var playerNameEl = $one('#history-player-name', wrap) || $one('#history-player-name');
      var playerName = playerNameEl ? normEs(playerNameEl.value) : '';

      // Dropdown
      var dd = $one('.history-search-dropdown', box);
      if (!dd){
        dd = D.createElement('div'); dd.className = 'history-search-dropdown rf-live-inline';
        // Posicionamiento estático para no tapar el input
        dd.style.display='none'; dd.style.marginTop='8px'; dd.style.maxHeight='320px'; dd.style.overflow='auto';
        dd.style.background='#fff'; dd.style.border='1px solid rgba(0,0,0,.12)'; dd.style.borderRadius='10px'; dd.style.boxShadow='0 10px 30px rgba(0,0,0,.12)';
        // Insertar DESPUÉS del buscador
        var holder = $one('.history-search-box', box) || box;
        if (holder.nextSibling) box.insertBefore(dd, holder.nextSibling); else box.appendChild(dd);
      }

      // Asegurar que la etiqueta ocupa línea completa
      var labelTop = $one('#history-global-label', box);
      if (labelTop){ labelTop.style.display='block'; labelTop.style.width='100%'; labelTop.style.flexBasis='100%'; }

      // Bloque inferior "RESULTADOS COMO COMPAÑERO"
      var split = $one('.history-split-counters', box);
      if (!split){
        split = D.createElement('div'); split.className = 'history-split-counters'; split.style.display='none'; split.style.marginTop='12px';
        split.style.width='100%'; split.style.flexBasis='100%';
        split.innerHTML = ''+
          '<div class="split-block split-comp">'
          +  '<div class="split-title" style="font-weight:700;color:#374151;margin:12px 2px 8px;">RESULTADOS COMO COMPAÑERO</div>'
          +  '<div class="history-summary-cards">'
          +    '<div class="hs-item hs-total"><span>Jugadas</span><strong class="v" data-k="comp-total">0</strong></div>'
          +    '<div class="hs-item hs-won"><span>Ganadas</span><strong class="v" data-k="comp-won">0</strong></div>'
          +    '<div class="hs-item hs-lost"><span>Perdidas</span><strong class="v" data-k="comp-lost">0</strong></div>'
          +    '<div class="hs-item hs-rate"><span>% Victorias</span><strong class="v" data-k="comp-rate">0%</strong></div>'
          +  '</div>'
          +'</div>';
        var searchBox = $one('.history-search-box', box);
        // Mantener el buscador en su posición original: insertar split DESPUÉS del buscador
        if (searchBox && searchBox.parentNode === box) {
          if (searchBox.nextSibling) box.insertBefore(split, searchBox.nextSibling);
          else box.appendChild(split);
        } else {
          box.appendChild(split);
        }
      }

      // Guardar totales base
      function num(s){ var n = parseFloat(String(s||'').replace(/[^0-9.,-]/g,'').replace(',','.')); return isNaN(n)?0:n; }
      var base = {
        total: num(($one('#hs-count-total', wrap)||{}).textContent),
        won:   num(($one('#hs-count-won', wrap)||{}).textContent),
        lost:  num(($one('#hs-count-lost', wrap)||{}).textContent),
        rate:  num(($one('#hs-count-rate', wrap)||{}).textContent)
      };
      // Fallback: si los contadores base vienen a 0 pero hay filas válidas, calcularlos desde las filas
      (function ensureBaseFromRows(){
        try {
          var needs = (base.total === 0 && rows && rows.length);
          if (!needs) return;
          var t=0,wc=0,lc=0;
          rows.forEach(function(r){
            var valid = (r.getAttribute('data-valid') === '1');
            if (!valid) return;
            t++;
            var w = r.getAttribute('data-win');
            if (w === '1') wc++; else if (w === '0') lc++;
          });
          if (t > 0) {
            base.total = t; base.won = wc; base.lost = lc; base.rate = (t? Math.round((wc*1000/t))/10 : 0);
            // Reflejar en UI por si los iniciales estaban a 0
            var elT=$one('#hs-count-total', wrap), elW=$one('#hs-count-won', wrap), elL=$one('#hs-count-lost', wrap), elR=$one('#hs-count-rate', wrap);
            if (elT) elT.textContent = String(base.total);
            if (elW) elW.textContent = String(base.won);
            if (elL) elL.textContent = String(base.lost);
            if (elR) elR.textContent = String(base.rate) + '%';
          }
        } catch(_){}
      })();

      function winnerText(row){ var a=row.getAttribute('data-names-winner'); if (a && a.trim()) return normEs(a); var el = $one('.history-match-winner', row); return normEs(el?el.textContent:''); }
      function loserText(row){ var a=row.getAttribute('data-names-loser');  if (a && a.trim()) return normEs(a); var el = $one('.history-match-loser', row);  return normEs(el?el.textContent:''); }
      function categorizeRow(row, q){
        var W=winnerText(row), L=loserText(row), hasW=W.indexOf(q)!==-1, hasL=L.indexOf(q)!==-1;
        if(!hasW && !hasL) return null;
        // 1) Si conocemos el lado del jugador, úsalo
        var side=(row.getAttribute('data-player-side')||'').toUpperCase();
        if(side==='W'){ return hasW?'companero':(hasL?'rival':null); }
        if(side==='L'){ return hasL?'companero':(hasW?'rival':null); }
        // 2) Si no, usa data-win (1 ganó el propio jugador; 0 perdió el propio jugador)
        var wAttr = row.getAttribute('data-win');
        if (wAttr === '1') { return hasW ? 'companero' : (hasL ? 'rival' : null); }
        if (wAttr === '0') { return hasL ? 'companero' : (hasW ? 'rival' : null); }
        // 3) Último recurso: si tenemos nombre del jugador, deduce por presencia en W/L
        if (playerName){
          var hasPW = W.indexOf(playerName)!==-1; var hasPL = L.indexOf(playerName)!==-1;
          if(hasPW&&hasW) return 'companero'; if(hasPL&&hasL) return 'companero';
          if(hasPW&&hasL) return 'rival';    if(hasPL&&hasW) return 'rival';
        }
        return null;
      }

      function renderDropdown(qRaw){
        var q = normEs(qRaw); if (!q){ dd.style.display='none'; dd.innerHTML=''; return; }
        var comp=0, riv=0, hits=0; var rows = getRows();
  rows.forEach(function(r){ var cat = categorizeRow(r,q); var txt = normEs(r.textContent||''); if (txt.indexOf(q)!==-1) hits++; if (cat==='companero') comp++; else if (cat==='rival') riv++; });
        if (!comp && !riv && hits){ dd.innerHTML=''; dd.style.display='none'; return; }
        var html = '';
        if (comp || riv){
          html += '<div class="rf-hint" style="padding:.5rem .8rem .2rem;color:#6b7280;font-size:.9em;">Elige cómo filtrar las partidas</div>';
        }
        if (comp){ html += '<div class="rf-group"><div class="rf-head" style="font-weight:600;padding:.5rem .8rem;color:#374151;display:flex;justify-content:space-between;align-items:center;">Compañero <span style="opacity:.75;font-weight:500">('+comp+')</span></div></div>'; }
        if (riv){  html += '<div class="rf-group"><div class="rf-head" style="font-weight:600;padding:.5rem .8rem;color:#374151;display:flex;justify-content:space-between;align-items:center;">Rival <span style="opacity:.75;font-weight:500">('+riv+')</span></div></div>'; }
        if (!comp && !riv && !hits){ html += '<div class="rf-empty" style="padding:.6rem .8rem;opacity:.8;color:#6b7280;">Sin coincidencias</div>'; }
        dd.innerHTML = html;
        function addAct(label, rel){ var b=D.createElement('button'); b.type='button'; b.textContent='Filtrar partidas como '+label; b.className='rf-act'; b.style.cssText='margin:.25rem .8rem .8rem;padding:.45rem .7rem;border-radius:999px;border:1px solid #d1d5db;background:#f9fafb;cursor:pointer;transition:all .15s ease;font-weight:500'; b.onmouseenter=function(){ b.style.background='#eef2ff'; b.style.borderColor='#c7d2fe'; }; b.onmouseleave=function(){ b.style.background='#f9fafb'; b.style.borderColor='#d1d5db'; }; b.addEventListener('click', function(){ applyFilter(q, rel); }); return b; }
        var groups = $all('.rf-group', dd); if (groups[0] && comp) groups[0].appendChild(addAct('Compañero','companero')); if (groups[groups.length-1] && riv) groups[groups.length-1].appendChild(addAct('Rival','rival'));
        dd.style.display = 'block';
      }

      function updateSplit(qRaw){
        if (window.rfDebug) console.log('[rf] updateSplit', qRaw);
        var q = normEs(qRaw), compT=0,compW=0,compL=0, rivT=0,rivW=0,rivL=0; var rows = getRows();
  if (q){ rows.forEach(function(r){ var cat=categorizeRow(r,q); if(!cat) return; var w=r.getAttribute('data-win'); var won=(w==='1'), lost=(w==='0'); if(cat==='companero'){ compT++; if(won)compW++; if(lost)compL++; } else if(cat==='rival'){ rivT++; if(won)rivW++; if(lost)rivL++; } }); }
        var compRate = compT>0? Math.round((compW*1000/compT))/10 : 0;
        var rivRate  = rivT>0 ? Math.round((rivW*1000/rivT))/10  : 0;
        function setSplit(k,v){ var el = split && $one('[data-k="'+k+'"]', split); if (el) el.textContent = String(v); }
        if (split){ setSplit('comp-total', compT); setSplit('comp-won', compW); setSplit('comp-lost', compL); setSplit('comp-rate', compRate+'%'); split.style.display = q ? '' : 'none'; }
        var label = $one('#history-global-label', box);
        var elT = $one('#hs-count-total', wrap), elW=$one('#hs-count-won', wrap), elL=$one('#hs-count-lost', wrap), elR=$one('#hs-count-rate', wrap);
        // Cambiar etiqueta si hay coincidencias H2H (rival o compañero) con el término
        var anyH2H = (compT + rivT) > 0;
        if (q && anyH2H){
          if(label){ label.textContent='RESULTADOS COMO RIVAL'; label.style.display='block'; label.style.width='100%'; label.style.flexBasis='100%'; }
          if(elT) elT.textContent=String(rivT); if(elW) elW.textContent=String(rivW); if(elL) elL.textContent=String(rivL); if(elR) elR.textContent=(rivRate)+'%';
        } else if (q && !anyH2H) {
          // Fallback: si no pudimos clasificar H2H, usa filas visibles tras el filtro como Rival
          var vT=0,vW=0,vL=0; rows.forEach(function(r){ if (!r.classList.contains('rf-hidden')){ vT++; var w=r.getAttribute('data-win'); if(w==='1') vW++; else if(w==='0') vL++; } });
          if (vT>0){
            if(label){ label.textContent='RESULTADOS COMO RIVAL'; label.style.display='block'; label.style.width='100%'; label.style.flexBasis='100%'; }
            if(elT) elT.textContent=String(vT); if(elW) elW.textContent=String(vW); if(elL) elL.textContent=String(vL); if(elR) elR.textContent=(vT? (Math.round((vW*1000/vT))/10) : 0)+'%';
          } else {
            if(label){ label.textContent='RESULTADOS GLOBALES'; label.style.display='block'; label.style.width='100%'; label.style.flexBasis='100%'; }
            if(elT) elT.textContent=String(base.total); if(elW) elW.textContent=String(base.won); if(elL) elL.textContent=String(base.lost); if(elR) elR.textContent=(base.rate)+'%';
          }
        } else {
          if(label){ label.textContent='RESULTADOS GLOBALES'; label.style.display='block'; label.style.width='100%'; label.style.flexBasis='100%'; }
          if(elT) elT.textContent=String(base.total); if(elW) elW.textContent=String(base.won); if(elL) elL.textContent=String(base.lost); if(elR) elR.textContent=(base.rate)+'%';
        }
      }

      function applyFilter(qRaw, relation){
        if (window.rfDebug) console.log('[rf] applyFilter', qRaw, relation);
        var q = normEs(qRaw||''); var any=0,won=0,lost=0; var rows = getRows();
        rows.forEach(function(r){
          var wl = (winnerText(r)+' '+loserText(r));
          var hit = !q || wl.indexOf(q)!==-1;
          if (!hit){
            // Fallback: si no encontró en ganador/perdedor, probar con todo el texto de la fila
            var all = normEs(r.textContent||'');
            hit = !q || all.indexOf(q)!==-1;
          }
          var show = hit;
          if (show && relation){ var cat = categorizeRow(r,q); show = (cat===relation); }
          if (show){
            r.classList.remove('rf-hidden');
            try { r.style.removeProperty('display'); } catch(_){ r.style.display=''; }
          } else {
            r.classList.add('rf-hidden');
            try { r.style.setProperty('display','none','important'); } catch(_){ r.style.display='none'; }
          }
          if (window.rfDebug) console.log('[rf] row', {row:r, wl, hit, show, relation});
          if (show){ any++; var w=r.getAttribute('data-win'); if(w==='1') won++; else if(w==='0') lost++; }
        });
        // Flag visual de filtro activo
        box.classList && box.classList.toggle('filter-on', !!q);
        var flag = $one('.filter-active-flag, .filter-active-flag-inline', box); if (flag) flag.style.display = q? '' : 'none';
        // No actualizar aquí los contadores superiores; se decide en updateSplit para mantener lógica de Rival
        // Ocultar/mostrar títulos y listas por sección (mostrar encabezados solo donde haya resultados)
        var relationOn = !!relation; // ya no oculta siempre; se usa para flags si hiciera falta
        $all('.history-matches-list', wrap).forEach(function(list){
          var anyVis = $all('.history-match-row', list).some(function(r){ return !r.classList.contains('rf-hidden'); });
          var title = (function(){ var prev=list.previousElementSibling; if(prev && prev.classList && prev.classList.contains('history-competition-title')) return prev; return $one('.history-competition-title', list); })();
          // Mostrar el encabezado si hay filas visibles; ocultarlo si no
          if (title) title.style.display = anyVis ? '' : 'none';
          list.style.display = anyVis ? '' : 'none';
        });
        // Ocultar/mostrar bloque de torneo y su header
        $all('.history-tournament-block', wrap).forEach(function(block){
          var any = $all('.history-matches-list', block).some(function(list){ return list.style.display !== 'none'; });
          // Mostrar encabezado de torneo si dentro hay listas con filas visibles; ocultar si no
          var th = $one('.tournament-header', block); if (th) th.style.display = any ? '' : 'none';
          block.style.display = any ? '' : 'none';
        });
        // Actualizar paneles (label fijo + split)
        updateSplit(q);
      }

      function onInput(){
        var val = (input.value||'').trim();
        if (!val){
          dd.style.display='none'; dd.innerHTML='';
          if (split) split.style.display='none';
          var label = $one('#history-global-label', box); if (label){ label.textContent='RESULTADOS GLOBALES'; label.style.display='block'; label.style.width='100%'; label.style.flexBasis='100%'; }
          var elT=$one('#hs-count-total', wrap), elW=$one('#hs-count-won', wrap), elL=$one('#hs-count-lost', wrap), elR=$one('#hs-count-rate', wrap);
          if (elT) elT.textContent=String(base.total); if (elW) elW.textContent=String(base.won); if (elL) elL.textContent=String(base.lost); if (elR) elR.textContent=(base.rate)+'%';
          // Asegurar que todas las filas vuelven a mostrarse
          getRows().forEach(function(r){ r.classList.remove('rf-hidden'); try{ r.style.removeProperty('display'); }catch(_){ r.style.display=''; } });
          box.classList && box.classList.remove('filter-on');
          applyFilter('', null);
          return;
        }
        renderDropdown(val);
        applyFilter(val, null);
      }

      input.addEventListener('input', onInput);
      input.addEventListener('keyup', onInput);
      // Cerrar dropdown con click fuera
      D.addEventListener('click', function(e){ var path = e.composedPath ? e.composedPath() : []; if (path.indexOf(dd)===-1 && path.indexOf(input)===-1){ dd.style.display='none'; } }, { capture: true, passive: true });

      // Inicial
      onInput();
    });
  }

  // Arranque inicial
  if (D.readyState === 'loading') D.addEventListener('DOMContentLoaded', setup);
  else setup();

  // Re-enganchar si el Historial se carga por AJAX/lazy (pestañas)
  try {
    var mo = new MutationObserver(function(muts){
      var needs = false;
      for (var i=0;i<muts.length;i++){
        var m = muts[i];
        if (m.type === 'childList'){
          if ((m.addedNodes && m.addedNodes.length) || (m.removedNodes && m.removedNodes.length)){
            needs = true; break;
          }
        }
      }
      if (needs) setup();
    });
    if (D.body) mo.observe(D.body, { childList: true, subtree: true });
    // Eventos personalizados de hidratación de pestañas (si existen)
    D.addEventListener('rf:tab:loaded', function(e){ setup(); }, { passive: true });
    D.addEventListener('rf:historial:loaded', function(e){ setup(); }, { passive: true });
  } catch(e) { /* noop */ }
})();