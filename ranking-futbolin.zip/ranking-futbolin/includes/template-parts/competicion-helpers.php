<?php
// _deprecated - usar includes/template-parts/_helpers.php
