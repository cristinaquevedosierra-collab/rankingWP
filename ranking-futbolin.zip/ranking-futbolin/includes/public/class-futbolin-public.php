
if (file_exists(FUTBOLIN_API_PATH . 'includes/public/class-futbolin-rankgen-route.php')) { require_once FUTBOLIN_API_PATH . 'includes/public/class-futbolin-rankgen-route.php'; }
