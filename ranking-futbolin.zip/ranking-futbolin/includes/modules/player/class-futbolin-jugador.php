<?php
/**
 * Archivo Resultante: class-futbolin-jugador.php
 * Ruta: includes/modules/player/class-futbolin-jugador.php
 * Fuente Original: class-futbolin-jugador.php (antiguo)
 */
if (!defined('ABSPATH')) exit;

class Futbolin_Jugador {
    public function __construct() {
        // La lógica del shortcode [futbolin_jugador] irá aquí.
    }
}