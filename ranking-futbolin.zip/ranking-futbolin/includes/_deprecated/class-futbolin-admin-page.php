<?php
/**
 * Archivo Resultante: class-futbolin-admin-page.php
 * Ruta: includes/class-futbolin-admin-page.php
 * Fuente Original: class-futbolin-admin.php (antiguo)
 */
if (!defined('ABSPATH')) exit;

class Futbolin_Admin_Page {
    public function __construct() {
        // La lógica para crear la página del panel de admin irá aquí.
    }
}