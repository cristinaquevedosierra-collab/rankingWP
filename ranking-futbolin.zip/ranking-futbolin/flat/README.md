Notas sobre la carpeta flat/
===========================

- Estos CSS son variantes planas/agrupadas pensadas para distribución o referencia.
- El plugin no encola archivos desde `flat/` en runtime. La prioridad real es:
  1) `dist/assets/css-purged/` (si existe)
  2) `assets/css/` (por defecto)
- Puedes usar `?rf_debug_css=1` para ver los orígenes de los estilos encolados.
